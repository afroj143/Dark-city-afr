const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const ui = {
  start: document.getElementById("startScreen"),
  startBtn: document.getElementById("startBtn"),
  riderName: document.getElementById("riderName"),
  hudName: document.getElementById("hudName"),
  money: document.getElementById("hudMoney"),
  time: document.getElementById("hudTime"),
  weather: document.getElementById("hudWeather"),
  missionTitle: document.getElementById("missionTitle"),
  missionText: document.getElementById("missionText"),
  fuel: document.getElementById("fuelMeter"),
  health: document.getElementById("healthMeter"),
  energy: document.getElementById("energyMeter"),
  rep: document.getElementById("repMeter"),
  phone: document.getElementById("phone"),
  closePhone: document.getElementById("closePhone"),
  hud: document.getElementById("hud"),
  hudToggle: document.getElementById("hudToggle"),
  congratsPopup: document.getElementById("congratsPopup"),
  congratsTitle: document.getElementById("congratsTitle"),
  congratsText: document.getElementById("congratsText"),
  closeCongrats: document.getElementById("closeCongrats"),
  tabContent: document.getElementById("tabContent"),
  toast: document.getElementById("toast")
};

const TAU = Math.PI * 2;
const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
const lerp = (a, b, t) => a + (b - a) * t;
const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const rnd = (min, max) => min + Math.random() * (max - min);

const input = {
  up: false,
  down: false,
  left: false,
  right: false,
  brake: false,
  interact: false,
  phone: false
};

const cityData = {
  Chengail: {
    center: { x: 0, y: 0 },
    color: "#24483e",
    mood: "Friendly starter town",
    landmarks: [
      ["Tea Stall", -320, -170, "shop"],
      ["Market", 90, -210, "shop"],
      ["Petrol Pump", 410, -70, "fuel"],
      ["Rafiq Garage", -520, 160, "garage"],
      ["School", -120, 360, "school"],
      ["Pharmacy", 330, 260, "shop"],
      ["River Bridge", 660, -340, "bridge"],
      ["AFROJ House", -650, -330, "home"],
      ["Park", 130, 470, "park"],
      ["ATM", 250, -410, "atm"]
    ]
  },
  Basudevpur: {
    center: { x: 2700, y: 0 },
    color: "#2e5c35",
    mood: "Quiet village and night mystery",
    landmarks: [
      ["Village Market", 2480, -180, "shop"],
      ["Rice Fields", 3050, -330, "field"],
      ["Bamboo Forest", 3250, 250, "forest"],
      ["Old Warehouse", 2360, 380, "warehouse"],
      ["Temple", 2820, 250, "temple"],
      ["Small Mosque", 2560, 300, "mosque"],
      ["Pond", 3020, 70, "pond"],
      ["Farm House", 2220, -330, "home"],
      ["Tractor Route", 3400, -90, "road"],
      ["Village Clinic", 2620, -430, "shop"]
    ]
  },
  Howrah: {
    center: { x: 5400, y: 0 },
    color: "#233746",
    mood: "Dense city, heavy rain, final truth",
    landmarks: [
      ["Railway Station", 5100, -390, "station"],
      ["Flyover", 5620, -250, "bridge"],
      ["Shopping Mall", 5360, 230, "shop"],
      ["Hospital", 5900, 90, "hospital"],
      ["Police Station", 5050, 260, "police"],
      ["Bus Stand", 4800, -90, "bus"],
      ["Industrial Area", 6200, -300, "warehouse"],
      ["Apartment Complex", 5700, 420, "home"],
      ["River Bridge", 6450, 120, "bridge"],
      ["Hotel District", 5250, 520, "hotel"]
    ]
  }
};

const allLandmarks = Object.entries(cityData).flatMap(([city, data]) =>
  data.landmarks.map(([name, x, y, type]) => ({ city, name, x, y, type }))
);

const weatherProfiles = [
  { name: "Sunny", fog: 0, rain: 0, wind: .05, grip: 1, sky: "#8bb9ca" },
  { name: "Cloudy", fog: .08, rain: 0, wind: .12, grip: .98, sky: "#5f7882" },
  { name: "Overcast", fog: .16, rain: 0, wind: .16, grip: .96, sky: "#465963" },
  { name: "Light Rain", fog: .18, rain: .35, wind: .2, grip: .88, sky: "#30414c" },
  { name: "Heavy Rain", fog: .25, rain: .75, wind: .32, grip: .75, sky: "#1f2d38" },
  { name: "Thunderstorm", fog: .34, rain: 1, wind: .55, grip: .66, sky: "#101b27" },
  { name: "Dense Fog", fog: .7, rain: 0, wind: .08, grip: .9, sky: "#b9c2bd" },
  { name: "Morning Mist", fog: .44, rain: 0, wind: .05, grip: .96, sky: "#b4c4b9" },
  { name: "Strong Wind", fog: .12, rain: .1, wind: .85, grip: .92, sky: "#354851" }
];

const state = {
  started: false,
  tab: "orders",
  t: 0,
  dayMinutes: 6 * 60,
  weatherIndex: 0,
  cameraMode: "map",
  nextWeather: 80,
  lightning: 0,
  camera: { x: 0, y: 0 },
  player: {
    name: "AFROJ",
    x: -650,
    y: -330,
    angle: -0.15,
    speed: 0,
    fuel: 100,
    health: 100,
    energy: 100,
    hunger: 100,
    money: 350,
    xp: 0,
    reputation: 8,
    bike: "Old Delivery Bike",
    bikeLevel: 1,
    dirt: 0,
    engine: 100
  },
  unlocked: { Chengail: true, Basudevpur: false, Howrah: false },
  completed: 0,
  moneyMilestonesShown: {},
  activeMission: null,
  missionStage: "none",
  clues: [],
  messages: [
    "Welcome to your first shift. Keep fuel, energy, and parcel condition under control."
  ],
  traffic: [],
  pedestrians: [],
  rainDrops: [],
  particles: []
};

const audio = {
  ctx: null,
  rainGain: null,
  stormGain: null,
  rainReady: false,
  lastThunder: 0
};

function initAudio() {
  if (audio.ctx) {
    if (audio.ctx.state === "suspended") audio.ctx.resume();
    return;
  }
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!AudioContext) return;
  audio.ctx = new AudioContext();
  audio.rainGain = audio.ctx.createGain();
  audio.stormGain = audio.ctx.createGain();
  audio.rainGain.gain.value = 0;
  audio.stormGain.gain.value = 0;
  audio.rainGain.connect(audio.ctx.destination);
  audio.stormGain.connect(audio.ctx.destination);

  const bufferSize = audio.ctx.sampleRate * 2;
  const buffer = audio.ctx.createBuffer(1, bufferSize, audio.ctx.sampleRate);
  const data = buffer.getChannelData(0);
  for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;

  const rain = audio.ctx.createBufferSource();
  const rainFilter = audio.ctx.createBiquadFilter();
  rain.buffer = buffer;
  rain.loop = true;
  rainFilter.type = "highpass";
  rainFilter.frequency.value = 900;
  rain.connect(rainFilter);
  rainFilter.connect(audio.rainGain);
  rain.start();

  const storm = audio.ctx.createBufferSource();
  const stormFilter = audio.ctx.createBiquadFilter();
  storm.buffer = buffer;
  storm.loop = true;
  stormFilter.type = "lowpass";
  stormFilter.frequency.value = 130;
  storm.connect(stormFilter);
  stormFilter.connect(audio.stormGain);
  storm.start();
  audio.rainReady = true;
}

function playTone(freq, duration, type = "sine", gain = .08, slideTo = null) {
  if (!audio.ctx) return;
  if (audio.ctx.state === "suspended") audio.ctx.resume();
  const now = audio.ctx.currentTime;
  const osc = audio.ctx.createOscillator();
  const amp = audio.ctx.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, now);
  if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, now + duration);
  amp.gain.setValueAtTime(0.0001, now);
  amp.gain.exponentialRampToValueAtTime(gain, now + .018);
  amp.gain.exponentialRampToValueAtTime(0.0001, now + duration);
  osc.connect(amp);
  amp.connect(audio.ctx.destination);
  osc.start(now);
  osc.stop(now + duration + .03);
}

function playHorn() {
  initAudio();
  playTone(430, .15, "square", .085);
  setTimeout(() => playTone(360, .12, "square", .07), 90);
  for (const v of state.traffic) {
    const d = Math.hypot(state.player.x - v.x, state.player.y - v.y);
    if (d < 230) {
      v.speed = clamp(v.speed * 1.08, .45, 2.4);
      v.angle += rnd(-.08, .08);
    }
  }
}

function playNotification() {
  initAudio();
  playTone(880, .08, "sine", .055);
  setTimeout(() => playTone(1175, .1, "sine", .05), 90);
}

function playPickupSound() {
  initAudio();
  playTone(520, .07, "triangle", .05);
  setTimeout(() => playTone(760, .09, "triangle", .055), 70);
}

function playThunderSound() {
  if (!audio.ctx) return;
  playTone(72, .7, "sawtooth", .09, 34);
  setTimeout(() => playTone(46, .9, "triangle", .055, 28), 120);
}

function playStormStartSound() {
  initAudio();
  playTone(92, .55, "sawtooth", .075, 44);
  setTimeout(() => playTone(58, .7, "triangle", .06, 31), 160);
  setTimeout(() => playTone(120, .35, "sawtooth", .04, 70), 420);
}

function playVictoryMusic(level = 1) {
  initAudio();
  const sets = [
    [523, 659, 784, 659],
    [523, 659, 784, 1046, 784],
    [587, 740, 880, 1174, 988, 880],
    [523, 659, 784, 1046, 988, 784, 880, 1046]
  ];
  const notes = sets[Math.min(sets.length - 1, level - 1)];
  notes.forEach((note, i) => {
    setTimeout(() => playTone(note, .22, "triangle", .065), i * 170);
  });
  setTimeout(() => playTone(392, .7, "sine", .045), 120);
  setTimeout(() => playTone(523, .7, "sine", .045), 460);
  setTimeout(() => playTone(659, .8, "sine", .04), 800);
}

function showCongratulations(amount) {
  if (state.moneyMilestonesShown[amount]) return;
  state.moneyMilestonesShown[amount] = true;
  ui.congratsTitle.textContent = `Congratulations ${state.player.name || "AFROJ"}`;
  ui.congratsText.textContent = `You completed ₹${amount.toLocaleString("en-IN")} earnings in Shadow Delivery: Dark City.`;
  ui.congratsPopup.classList.add("show");
  const level = [1000, 3000, 5000, 10000].indexOf(amount) + 1;
  playVictoryMusic(level);
}

function checkMoneyMilestones() {
  for (const amount of [1000, 3000, 5000, 10000]) {
    if (state.player.money >= amount && !state.moneyMilestonesShown[amount]) {
      showCongratulations(amount);
      break;
    }
  }
}

function updateEnvironmentalAudio() {
  if (!audio.ctx || !audio.rainReady) return;
  const w = currentWeather();
  const rainTarget = state.started ? w.rain * .17 : 0;
  const stormTarget = state.started && w.name === "Thunderstorm" ? .24 : state.started && w.name === "Heavy Rain" ? .06 : 0;
  const now = audio.ctx.currentTime;
  audio.rainGain.gain.linearRampToValueAtTime(rainTarget, now + .4);
  audio.stormGain.gain.linearRampToValueAtTime(stormTarget, now + .6);
}

const missionNames = [
  "New Rider", "Tea Stall Parcel", "Medicine Run", "Fuel Lesson", "School Lunch",
  "Wrong Lane", "Rain Practice", "Garage Visit", "Unknown Number", "Address Not Found",
  "Morning Groceries", "ATM Envelope", "Park Photograph", "Bridge Delay", "Hungry Shift",
  "Customer Rating", "The Silent House", "Missing Receipt", "Night Tea", "First Clue",
  "Heavy Rain Order", "Slippery Roads", "Pharmacy Emergency", "Broken Headlight", "The Second Call",
  "Parcel Without Sender", "Riverbank Drop", "Police Checkpoint", "Hidden Note", "Leaving Chengail",
  "Village Welcome", "Dirt Road Test", "Rice Field Route", "Temple Flowers", "Mosque Donation Box",
  "Pond Shortcut", "Tractor Jam", "Bamboo Forest Path", "Old Warehouse Sighted", "Village Whisper",
  "Milk Delivery", "Goat Trouble", "Doctor’s Bag", "Fog Ride", "Abandoned Bicycle",
  "The Girl’s Letter", "No Return Address", "Night at the Pond", "Warehouse Key", "Locked Gate",
  "Secret Pickup", "No Headlights", "Empty Warehouse", "Document Box", "Chased by Time",
  "Broken Phone Signal", "The Missing Rider", "Hidden Ledger", "Anonymous Warning", "Road to Howrah",
  "City Arrival", "Railway Rush", "Flyover Speed", "Mall Food Court", "Hospital Emergency",
  "Apartment Maze", "Traffic Signal Test", "Rainy Flyover", "Police Station File", "Case Reopened",
  "VIP Hotel Delivery", "Industrial Smoke", "Bus Stand Chaos", "Ambulance Escort", "Broken Package",
  "Camera Evidence", "Fake Customer", "Rain Blackout", "Last Seen Location", "Warehouse Network",
  "Door 404", "Three Same Names", "Restaurant Backroom", "Signal Lost", "Bridge Package",
  "The Witness", "Old SIM Card", "Silent Customer", "Rain Evidence", "AFROJ Followed",
  "Family Photo", "Mother’s Request", "Hospital Record", "Police Doubt", "Proof of Route",
  "Secret Locker", "The Real Company", "Corrupt Manager", "Escape Route", "Truth in the Rain",
  "Final Ledger", "Industrial Night", "No Backup", "Lost Rider’s Helmet", "Recorded Call",
  "Train Yard Route", "Wrong Police Van", "The Hidden Office", "Save the Witness", "Citywide Alert",
  "Last Delivery Request", "All Roads Closed", "Storm Warning", "Across the Bridge", "The Real Sender",
  "Sameer’s Truth", "Choice of Silence", "Final Evidence Drop", "Morning After", "Shadow Delivery"
];

function missionCity(index) {
  if (index < 30) return "Chengail";
  if (index < 60) return "Basudevpur";
  return "Howrah";
}

const missions = missionNames.map((title, i) => {
  const city = missionCity(i);
  const points = allLandmarks.filter(p => p.city === city);
  const pickup = points[(i * 3 + 1) % points.length];
  const drop = points[(i * 5 + 4) % points.length];
  const secret = /Unknown|Address|Clue|Warehouse|Missing|Secret|Fake|Truth|Caller|Ledger|Evidence|Sameer|Silent|Final/.test(title);
  return {
    id: i + 1,
    title,
    city,
    chapter: Math.floor(i / 10) + 1,
    type: secret ? "Story Mystery" : ["Food", "Medicine", "Parcel", "VIP", "Rain", "Emergency"][i % 6],
    pickup,
    drop,
    reward: 80 + Math.floor(i * 7.5),
    xp: 15 + i * 2,
    timeLimit: 120 + Math.max(0, 240 - i),
    secret,
    weather: i % 9 === 0 ? "Light Rain" : i % 13 === 0 ? "Heavy Rain" : null,
    briefing: secret
      ? "A strange job appears with incomplete customer details. Check the location and record anything unusual."
      : "Complete the delivery cleanly. Avoid crashes, save fuel, and keep the customer rating high."
  };
});

function resize() {
  const dpr = Math.min(2, window.devicePixelRatio || 1);
  canvas.width = Math.floor(innerWidth * dpr);
  canvas.height = Math.floor(innerHeight * dpr);
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

function showToast(text) {
  ui.toast.textContent = text;
  ui.toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => ui.toast.classList.remove("show"), 1200);
}

function setWeather(name) {
  const idx = weatherProfiles.findIndex(w => w.name === name);
  if (idx >= 0) state.weatherIndex = idx;
}

function currentWeather() {
  return weatherProfiles[state.weatherIndex];
}

function currentCity() {
  let best = "Chengail";
  let bestD = Infinity;
  for (const [name, c] of Object.entries(cityData)) {
    const d = Math.hypot(state.player.x - c.center.x, state.player.y - c.center.y);
    if (d < bestD) {
      best = name;
      bestD = d;
    }
  }
  return best;
}

function timeLabel() {
  const m = Math.floor(state.dayMinutes) % 1440;
  const h = Math.floor(m / 60);
  const mm = m % 60;
  return `${String(h).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
}

function phaseOfDay() {
  const m = state.dayMinutes % 1440;
  if (m < 270) return "Midnight";
  if (m < 420) return "Early Dawn";
  if (m < 720) return "Morning";
  if (m < 1020) return "Afternoon";
  if (m < 1200) return "Evening";
  return "Night";
}

function availableMissions() {
  const next = missions.find(m => m.id === state.completed + 1);
  const city = currentCity();
  const side = missions
    .filter(m => state.unlocked[m.city] && m.id > state.completed + 1 && m.city === city)
    .slice(0, 3);
  return [next, ...side].filter(Boolean).filter(m => state.unlocked[m.city]);
}

function acceptMission(id) {
  const mission = missions.find(m => m.id === id);
  if (!mission) return;
  if (!state.unlocked[mission.city]) {
    showToast(`${mission.city} is locked. Progress the story to unlock it.`);
    return;
  }
  state.activeMission = mission;
  state.missionStage = "pickup";
  if (mission.weather) setWeather(mission.weather);
  ui.phone.classList.remove("open");
  playNotification();
  showToast(`Mission accepted: ${mission.title}`);
}

function completeMission() {
  const mission = state.activeMission;
  if (!mission) return;
  const speedPenalty = Math.abs(state.player.speed) > 7 ? 8 : 0;
  const weatherBonus = currentWeather().rain > .3 ? 40 : 0;
  const reward = mission.reward + weatherBonus - speedPenalty;
  state.player.money += Math.max(30, reward);
  state.player.xp += mission.xp;
  state.player.reputation = clamp(state.player.reputation + (mission.secret ? 2 : 1), 0, 100);
  state.completed = Math.max(state.completed, mission.id);
  state.messages.push(`Completed ${mission.title}. Rating improved.`);

  if (mission.id === 30) {
    state.unlocked.Basudevpur = true;
    state.messages.push("New route unlocked: Basudevpur village road.");
  }
  if (mission.id === 60) {
    state.unlocked.Howrah = true;
    state.messages.push("New route unlocked: Howrah city express road.");
  }
  if (mission.secret || mission.id % 10 === 0) {
    const clue = {
      title: `Clue ${state.clues.length + 1}: ${mission.title}`,
      text: mission.id < 60
        ? "A delivery record mentions Sameer, a rider who vanished after a warehouse job."
        : mission.id < 100
          ? "Multiple fake customer identities connect the city orders to industrial warehouses."
          : "The final evidence points toward a hidden parcel-routing network."
    };
    state.clues.push(clue);
    state.messages.push(`Shadow Note added: ${clue.title}`);
  }

  state.activeMission = null;
  state.missionStage = "none";
  showToast(`Delivery complete. Earned ₹${Math.max(30, reward)}.`);
  renderPhone();
}

function interact() {
  const p = state.player;
  const nearby = allLandmarks.find(l => Math.hypot(p.x - l.x, p.y - l.y) < 92);
  const mission = state.activeMission;

  if (mission) {
    const target = state.missionStage === "pickup" ? mission.pickup : mission.drop;
    if (Math.hypot(p.x - target.x, p.y - target.y) < 115) {
      if (state.missionStage === "pickup") {
        state.missionStage = "drop";
        state.messages.push(`Parcel collected from ${target.name}.`);
        playPickupSound();
        showToast(`Parcel collected. Ride to ${mission.drop.name}.`);
      } else {
        playPickupSound();
        completeMission();
      }
      return;
    }
  }

  if (!nearby) {
    showToast("No interaction nearby.");
    return;
  }

  if (nearby.type === "fuel") {
    const cost = Math.round((100 - p.fuel) * 1.6);
    if (p.money >= cost) {
      p.money -= cost;
      p.fuel = 100;
      showToast(`Fuel tank filled for ₹${cost}.`);
    } else showToast("Not enough money for full fuel.");
  } else if (nearby.type === "garage") {
    const repair = Math.round((100 - p.engine) * 2.2);
    if (p.money >= repair) {
      p.money -= repair;
      p.engine = 100;
      p.dirt = 0;
      showToast(`Bike repaired and washed for ₹${repair}.`);
    } else showToast("Rafiq: Bring more cash and I will fix the bike.");
  } else if (nearby.type === "shop" || nearby.type === "hotel") {
    if (p.money >= 45) {
      p.money -= 45;
      p.energy = clamp(p.energy + 16, 0, 100);
      p.hunger = clamp(p.hunger + 22, 0, 100);
      showToast(`Ate at ${nearby.name}. Energy restored.`);
    } else showToast("Not enough money to eat.");
  } else if (nearby.type === "home") {
    p.energy = 100;
    p.health = 100;
    p.hunger = clamp(p.hunger + 30, 0, 100);
    state.dayMinutes = (Math.floor(state.dayMinutes / 1440) * 1440) + 6 * 60;
    showToast("Rested at home. Morning shift begins.");
  } else {
    showToast(`${nearby.name}: ${cityData[nearby.city].mood}.`);
  }
}

function travelTo(city) {
  if (!state.unlocked[city]) {
    showToast(`${city} is locked by story progression.`);
    return;
  }
  const c = cityData[city].center;
  state.player.x = c.x - 280;
  state.player.y = c.y - 120;
  state.player.speed = 0;
  ui.phone.classList.remove("open");
  showToast(`Travelled to ${city}.`);
}

function renderPhone() {
  document.querySelectorAll(".tabs button").forEach(b => {
    b.classList.toggle("on", b.dataset.tab === state.tab);
  });

  if (state.tab === "orders") {
    const list = availableMissions();
    ui.tabContent.innerHTML = list.length ? list.map(m => `
      <article class="card">
        <h3>${m.id}. ${m.title}</h3>
        <p><b>${m.city}</b> · ${m.type} · Chapter ${m.chapter}</p>
        <p>${m.briefing}</p>
        <p>Pickup: ${m.pickup.name} → Drop: ${m.drop.name}</p>
        <p>Reward: ₹${m.reward} · XP ${m.xp}</p>
        <button onclick="acceptMission(${m.id})">Accept Order</button>
      </article>
    `).join("") : `<article class="card"><h3>No orders</h3><p>Progress or travel to another unlocked city.</p></article>`;
  }

  if (state.tab === "map") {
    ui.tabContent.innerHTML = Object.keys(cityData).map(city => `
      <article class="card">
        <h3>${city} ${state.unlocked[city] ? "" : "Locked"}</h3>
        <p>${cityData[city].mood}</p>
        <p>${cityData[city].landmarks.map(l => l[0]).slice(0, 5).join(" · ")}</p>
        <button onclick="travelTo('${city}')">${state.unlocked[city] ? "Travel" : "Locked"}</button>
      </article>
    `).join("");
  }

  if (state.tab === "notes") {
    const notes = state.clues.length ? state.clues.map(c => `
      <article class="card"><h3>${c.title}</h3><p>${c.text}</p></article>
    `).join("") : `<article class="card"><h3>No clues yet</h3><p>Secret deliveries, fake addresses, and warehouse jobs add Shadow Notes.</p></article>`;
    ui.tabContent.innerHTML = `
      <article class="card">
        <h3>Messages</h3>
        ${state.messages.slice(-5).reverse().map(m => `<p>• ${m}</p>`).join("")}
      </article>${notes}`;
  }

  if (state.tab === "garage") {
    ui.tabContent.innerHTML = `
      <article class="card">
        <h3>${state.player.bike}</h3>
        <p>Engine: ${Math.round(state.player.engine)}% · Dirt: ${Math.round(state.player.dirt)}%</p>
        <p>Current bike level: ${state.player.bikeLevel}</p>
        <button onclick="upgradeBike()">Upgrade Bike</button>
      </article>
      <article class="card">
        <h3>Unlock Path</h3>
        <p>Old Delivery Bike → Scooter → Street Bike → Sports Bike → Adventure Bike → Premium Bike</p>
      </article>`;
  }
}

function upgradeBike() {
  const names = ["Old Delivery Bike", "Scooter", "Street Bike", "Sports Bike", "Adventure Bike", "Premium Bike"];
  if (state.player.bikeLevel >= names.length) {
    showToast("Premium Bike already unlocked.");
    return;
  }
  const cost = 650 * state.player.bikeLevel;
  if (state.player.money < cost) {
    showToast(`Need ₹${cost} to unlock the next bike.`);
    return;
  }
  state.player.money -= cost;
  state.player.bikeLevel += 1;
  state.player.bike = names[state.player.bikeLevel - 1];
  showToast(`Unlocked ${state.player.bike}.`);
  renderPhone();
}

window.acceptMission = acceptMission;
window.travelTo = travelTo;
window.upgradeBike = upgradeBike;

function routeForCity(city) {
  const c = cityData[city].center;
  if (city === "Howrah") {
    return [
      { x: c.x - 820, y: c.y - 520 }, { x: c.x + 820, y: c.y - 520 },
      { x: c.x + 820, y: c.y }, { x: c.x + 520, y: c.y + 520 },
      { x: c.x - 820, y: c.y + 520 }, { x: c.x - 820, y: c.y }
    ];
  }
  if (city === "Basudevpur") {
    return [
      { x: c.x - 760, y: c.y }, { x: c.x - 420, y: c.y - 360 },
      { x: c.x + 420, y: c.y - 360 }, { x: c.x + 760, y: c.y },
      { x: c.x + 420, y: c.y + 380 }, { x: c.x - 520, y: c.y + 360 }
    ];
  }
  return [
    { x: c.x - 820, y: c.y }, { x: c.x - 520, y: c.y - 520 },
    { x: c.x + 660, y: c.y - 520 }, { x: c.x + 820, y: c.y },
    { x: c.x + 560, y: c.y + 520 }, { x: c.x - 720, y: c.y + 520 }
  ];
}

function spawnWorldActors() {
  state.traffic.length = 0;
  state.pedestrians.length = 0;
  for (const [city, data] of Object.entries(cityData)) {
    const density = city === "Howrah" ? 30 : city === "Basudevpur" ? 12 : 18;
    const route = routeForCity(city);
    for (let i = 0; i < density; i++) {
      const routeIndex = i % route.length;
      const point = route[routeIndex];
      const next = route[(routeIndex + 1) % route.length];
      const angle = Math.atan2(next.y - point.y, next.x - point.x);
      const lane = i % 2 === 0 ? -28 : 28;
      state.traffic.push({
        city,
        x: point.x + Math.cos(angle) * rnd(0, 260) + Math.cos(angle + Math.PI / 2) * lane,
        y: point.y + Math.sin(angle) * rnd(0, 260) + Math.sin(angle + Math.PI / 2) * lane,
        angle,
        lane,
        routeIndex: (routeIndex + 1) % route.length,
        speed: rnd(.65, city === "Howrah" ? 1.8 : 1.45),
        type: ["bike", "car", "auto", "bus", "truck", "police"][Math.floor(Math.random() * 6)],
        color: ["#f6a441", "#e2e7da", "#3b87a3", "#b63f31", "#22313d", "#87a85b"][Math.floor(Math.random() * 6)]
      });
    }
    for (let i = 0; i < density * 1.2; i++) {
      state.pedestrians.push({
        city,
        x: data.center.x + rnd(-720, 720),
        y: data.center.y + rnd(-500, 500),
        vx: rnd(-.28, .28),
        vy: rnd(-.28, .28),
        umbrella: Math.random() < .45,
        animal: Math.random() < (city === "Basudevpur" ? .28 : .09)
      });
    }
  }
  for (let i = 0; i < 180; i++) {
    state.rainDrops.push({ x: rnd(0, innerWidth), y: rnd(0, innerHeight), s: rnd(8, 20), a: rnd(.2, .9) });
  }
}

function worldToScreen(x, y) {
  return {
    x: x - state.camera.x + innerWidth / 2,
    y: y - state.camera.y + innerHeight / 2
  };
}

function visibleWorldBounds() {
  return {
    left: state.camera.x - innerWidth / 2 - 250,
    right: state.camera.x + innerWidth / 2 + 250,
    top: state.camera.y - innerHeight / 2 - 250,
    bottom: state.camera.y + innerHeight / 2 + 250
  };
}

function drawRoundedRect(x, y, w, h, r) {
  ctx.beginPath();
  ctx.roundRect(x, y, w, h, r);
  ctx.fill();
}

function drawWorld() {
  const w = currentWeather();
  const phase = phaseOfDay();
  const night = phase === "Night" || phase === "Midnight" ? .72 : phase === "Evening" || phase === "Early Dawn" ? .38 : .08;
  const gradient = ctx.createLinearGradient(0, 0, innerWidth, innerHeight);
  gradient.addColorStop(0, w.sky);
  gradient.addColorStop(1, "#061016");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, innerWidth, innerHeight);

  drawGroundTexture(night);
  drawRoadNetwork();
  drawLandmarks();
  drawActors();
  drawMissionMarkers();
  drawPlayer();
  drawWeatherEffects(w, night);
  drawMiniMap();
}

function drawGroundTexture(night) {
  const bounds = visibleWorldBounds();
  for (const [city, data] of Object.entries(cityData)) {
    const c = worldToScreen(data.center.x, data.center.y);
    const grd = ctx.createRadialGradient(c.x, c.y, 80, c.x, c.y, 1120);
    grd.addColorStop(0, data.color + "cc");
    grd.addColorStop(1, "rgba(3, 11, 14, 0)");
    ctx.fillStyle = grd;
    ctx.fillRect(0, 0, innerWidth, innerHeight);
  }

  ctx.globalAlpha = .08 + night * .05;
  ctx.strokeStyle = "#d7e8e0";
  ctx.lineWidth = 1;
  const grid = 120;
  for (let x = Math.floor(bounds.left / grid) * grid; x < bounds.right; x += grid) {
    const s = worldToScreen(x, bounds.top);
    ctx.beginPath();
    ctx.moveTo(s.x, 0);
    ctx.lineTo(s.x + 40, innerHeight);
    ctx.stroke();
  }
  ctx.globalAlpha = 1;
}

function roadSegmentsForCity(center) {
  const x = center.x, y = center.y;
  return [
    [x - 900, y, x + 900, y, 72],
    [x, y - 620, x, y + 620, 68],
    [x - 650, y - 360, x + 620, y + 380, 46],
    [x - 660, y + 370, x + 700, y - 340, 42],
    [x - 840, y - 520, x + 840, y - 520, 38],
    [x - 840, y + 520, x + 840, y + 520, 38]
  ];
}

function drawRoadNetwork() {
  ctx.lineCap = "round";
  for (const data of Object.values(cityData)) {
    for (const r of roadSegmentsForCity(data.center)) {
      const a = worldToScreen(r[0], r[1]);
      const b = worldToScreen(r[2], r[3]);
      ctx.strokeStyle = "#1c2529";
      ctx.lineWidth = r[4] + 10;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
      ctx.strokeStyle = currentWeather().rain > .2 ? "rgba(85,116,126,.72)" : "#303b3f";
      ctx.lineWidth = r[4];
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
      ctx.setLineDash([18, 22]);
      ctx.strokeStyle = "rgba(236, 228, 188, .42)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
      ctx.setLineDash([]);
    }
  }

  ctx.strokeStyle = "rgba(40,70,83,.9)";
  ctx.lineWidth = 54;
  let a = worldToScreen(850, -10);
  let b = worldToScreen(1850, -10);
  ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
  a = worldToScreen(3550, -10);
  b = worldToScreen(4550, -10);
  ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
}

function drawLandmarks() {
  for (const l of allLandmarks) {
    const s = worldToScreen(l.x, l.y);
    if (s.x < -140 || s.y < -140 || s.x > innerWidth + 140 || s.y > innerHeight + 140) continue;
    const colors = {
      shop: "#ff9d36", fuel: "#50c16b", garage: "#7aaec8", school: "#e9d46a",
      bridge: "#a4aeb5", home: "#d06b4a", park: "#55bd72", atm: "#9bcae6",
      field: "#72b960", forest: "#2f8b55", warehouse: "#696e78", temple: "#f2c36d",
      mosque: "#84d7b0", pond: "#57a6c0", station: "#d9d5c7", hospital: "#ff6a6a",
      police: "#7495e9", bus: "#f09b36", hotel: "#d68cd8", road: "#909b83"
    };
    ctx.fillStyle = "rgba(0,0,0,.35)";
    drawRoundedRect(s.x - 34, s.y - 28, 68, 56, 10);
    ctx.fillStyle = colors[l.type] || "#ddd";
    drawRoundedRect(s.x - 25, s.y - 21, 50, 42, 8);
    ctx.fillStyle = "rgba(255,255,255,.75)";
    ctx.font = "12px Rajdhani";
    ctx.textAlign = "center";
    ctx.fillText(l.name, s.x, s.y - 33);
  }
}

function drawActors() {
  const w = currentWeather();
  for (const v of state.traffic) {
    const route = routeForCity(v.city);
    const target = route[v.routeIndex || 0];
    const targetAngle = Math.atan2(target.y - v.y, target.x - v.x);
    let turn = targetAngle - v.angle;
    while (turn > Math.PI) turn -= TAU;
    while (turn < -Math.PI) turn += TAU;
    v.angle += clamp(turn, -.035, .035);
    const trafficSlow = currentCity() === v.city && Math.hypot(state.player.x - v.x, state.player.y - v.y) < 90 ? .45 : 1;
    v.x += Math.cos(v.angle) * v.speed * (1 - w.rain * .28) * trafficSlow;
    v.y += Math.sin(v.angle) * v.speed * (1 - w.rain * .28) * trafficSlow;
    if (Math.hypot(v.x - target.x, v.y - target.y) < 70) {
      v.routeIndex = ((v.routeIndex || 0) + 1) % route.length;
    }
    const s = worldToScreen(v.x, v.y);
    if (s.x < -80 || s.y < -80 || s.x > innerWidth + 80 || s.y > innerHeight + 80) continue;
    ctx.save();
    ctx.translate(s.x, s.y);
    ctx.rotate(v.angle);
    ctx.fillStyle = "rgba(0,0,0,.35)";
    ctx.fillRect(-20, -12, 40, 24);
    ctx.fillStyle = v.color;
    ctx.fillRect(-17, -9, 34, 18);
    ctx.fillStyle = "rgba(255,231,169,.85)";
    ctx.fillRect(10, -7, 5, 5);
    ctx.fillRect(10, 2, 5, 5);
    ctx.restore();

    const d = Math.hypot(state.player.x - v.x, state.player.y - v.y);
    if (d < 34 && Math.abs(state.player.speed) > 2) {
      state.player.health = clamp(state.player.health - .12 * Math.abs(state.player.speed), 0, 100);
      state.player.engine = clamp(state.player.engine - .10 * Math.abs(state.player.speed), 0, 100);
      state.player.speed *= .94;
    }
  }

  for (const p of state.pedestrians) {
    const c = cityData[p.city].center;
    p.x += p.vx * (w.rain > .4 ? 1.8 : 1);
    p.y += p.vy * (w.rain > .4 ? 1.8 : 1);
    if (Math.hypot(p.x - c.x, p.y - c.y) > 790) {
      p.vx *= -1;
      p.vy *= -1;
    }
    const s = worldToScreen(p.x, p.y);
    if (s.x < -30 || s.y < -30 || s.x > innerWidth + 30 || s.y > innerHeight + 30) continue;
    ctx.fillStyle = p.animal ? "#d8c09a" : "#dce7df";
    ctx.beginPath();
    ctx.arc(s.x, s.y, p.animal ? 5 : 4, 0, TAU);
    ctx.fill();
    if (p.umbrella && w.rain > .2) {
      ctx.strokeStyle = "#ff9d36";
      ctx.beginPath();
      ctx.arc(s.x, s.y - 4, 10, Math.PI, TAU);
      ctx.stroke();
    }
  }
}

function drawMissionMarkers() {
  const mission = state.activeMission;
  if (!mission) return;
  const target = state.missionStage === "pickup" ? mission.pickup : mission.drop;
  const s = worldToScreen(target.x, target.y);
  const pulse = 1 + Math.sin(state.t * 6) * .12;
  ctx.strokeStyle = state.missionStage === "pickup" ? "#ff9d36" : "#49c56d";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(s.x, s.y, 42 * pulse, 0, TAU);
  ctx.stroke();
  ctx.fillStyle = "rgba(5, 12, 15, .82)";
  drawRoundedRect(s.x - 82, s.y - 70, 164, 30, 12);
  ctx.fillStyle = "#fff";
  ctx.font = "700 14px Rajdhani";
  ctx.textAlign = "center";
  ctx.fillText(state.missionStage === "pickup" ? "PICKUP" : "DROP", s.x, s.y - 50);
}

function drawPlayer() {
  const p = state.player;
  const s = worldToScreen(p.x, p.y);
  ctx.save();
  ctx.translate(s.x, s.y);
  ctx.rotate(p.angle);
  if (phaseOfDay() === "Night" || phaseOfDay() === "Midnight" || currentWeather().fog > .3) {
    const beam = ctx.createLinearGradient(18, 0, 180, 0);
    beam.addColorStop(0, "rgba(255,216,142,.5)");
    beam.addColorStop(1, "rgba(255,216,142,0)");
    ctx.fillStyle = beam;
    ctx.beginPath();
    ctx.moveTo(10, -14);
    ctx.lineTo(190, -62);
    ctx.lineTo(190, 62);
    ctx.lineTo(10, 14);
    ctx.closePath();
    ctx.fill();
  }
  ctx.fillStyle = "rgba(0,0,0,.45)";
  ctx.fillRect(-24, -13, 48, 26);
  ctx.fillStyle = "#111a20";
  ctx.fillRect(-22, -8, 44, 16);
  ctx.fillStyle = "#ff9d36";
  ctx.fillRect(-8, -13, 18, 26);
  ctx.fillStyle = "#e7f7ef";
  ctx.beginPath();
  ctx.arc(-7, 0, 8, 0, TAU);
  ctx.fill();
  ctx.fillStyle = "#ffe49b";
  ctx.fillRect(18, -6, 5, 4);
  ctx.fillRect(18, 2, 5, 4);
  ctx.restore();
}

function drawWeatherEffects(w, night) {
  if (w.rain > .05) {
    ctx.strokeStyle = `rgba(154, 202, 224, ${.24 + w.rain * .42})`;
    ctx.lineWidth = 1.4;
    for (const d of state.rainDrops) {
      d.x += w.wind * 8;
      d.y += d.s * (.7 + w.rain);
      if (d.y > innerHeight + 20) { d.y = -20; d.x = rnd(-80, innerWidth + 80); }
      if (d.x > innerWidth + 80) d.x = -80;
      ctx.beginPath();
      ctx.moveTo(d.x, d.y);
      ctx.lineTo(d.x - 7 - w.wind * 8, d.y + d.s);
      ctx.stroke();
    }
  }

  if (w.rain > .25) {
    ctx.globalAlpha = .25;
    for (let i = 0; i < 28; i++) {
      const x = (i * 211 + state.t * 20) % innerWidth;
      const y = (i * 97) % innerHeight;
      ctx.strokeStyle = "#9bcfe3";
      ctx.beginPath();
      ctx.ellipse(x, y, 12 + i % 7, 4, 0, 0, TAU);
      ctx.stroke();
    }
    ctx.globalAlpha = 1;
  }

  if (w.fog > .05) {
    ctx.fillStyle = `rgba(205, 223, 218, ${w.fog * .38})`;
    ctx.fillRect(0, 0, innerWidth, innerHeight);
  }

  if (night > .02) {
    ctx.fillStyle = `rgba(0, 8, 15, ${night})`;
    ctx.fillRect(0, 0, innerWidth, innerHeight);
    for (const l of allLandmarks) {
      if (["shop", "fuel", "garage", "home", "hotel", "hospital", "station"].includes(l.type)) {
        const s = worldToScreen(l.x, l.y);
        const g = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, 130);
        g.addColorStop(0, "rgba(255, 158, 54, .22)");
        g.addColorStop(1, "rgba(255, 158, 54, 0)");
        ctx.fillStyle = g;
        ctx.fillRect(s.x - 140, s.y - 140, 280, 280);
      }
    }
  }

  if (state.lightning > 0) {
    ctx.fillStyle = `rgba(220, 241, 255, ${state.lightning})`;
    ctx.fillRect(0, 0, innerWidth, innerHeight);
  }
}

function drawMiniMap() {
  const x = innerWidth - 162, y = 92, size = 140;
  ctx.fillStyle = "rgba(4, 11, 15, .72)";
  drawRoundedRect(x, y, size, size, 18);
  ctx.strokeStyle = "rgba(255,255,255,.18)";
  ctx.strokeRect(x + 10, y + 10, size - 20, size - 20);
  const city = cityData[currentCity()];
  const sx = (state.player.x - city.center.x) / 14 + x + size / 2;
  const sy = (state.player.y - city.center.y) / 14 + y + size / 2;
  ctx.fillStyle = "#ff9d36";
  ctx.beginPath(); ctx.arc(clamp(sx, x + 14, x + size - 14), clamp(sy, y + 14, y + size - 14), 5, 0, TAU); ctx.fill();
  if (state.activeMission) {
    const target = state.missionStage === "pickup" ? state.activeMission.pickup : state.activeMission.drop;
    if (target.city === currentCity()) {
      ctx.fillStyle = state.missionStage === "pickup" ? "#ffd180" : "#63e681";
      ctx.beginPath();
      ctx.arc(clamp((target.x - city.center.x) / 14 + x + size / 2, x + 12, x + size - 12),
        clamp((target.y - city.center.y) / 14 + y + size / 2, y + 12, y + size - 12), 5, 0, TAU);
      ctx.fill();
    }
  }
  ctx.fillStyle = "#d9ebe7";
  ctx.font = "700 13px Rajdhani";
  ctx.textAlign = "center";
  ctx.fillText(currentCity(), x + size / 2, y + size - 14);
}

function toDriverSpace(x, y) {
  const p = state.player;
  const dx = x - p.x;
  const dy = y - p.y;
  const ca = Math.cos(-p.angle);
  const sa = Math.sin(-p.angle);
  return {
    forward: dx * ca - dy * sa,
    side: dx * sa + dy * ca
  };
}

function projectDriver(forward, side, height = 0) {
  const horizon = innerHeight * .43;
  const scale = 760 / Math.max(70, forward);
  return {
    x: innerWidth / 2 + side * scale,
    y: horizon + 108000 / Math.max(120, forward) - height * scale,
    s: scale
  };
}

function drawDriverWorld() {
  const w = currentWeather();
  const phase = phaseOfDay();
  const night = phase === "Night" || phase === "Midnight" ? .78 : phase === "Evening" || phase === "Early Dawn" ? .42 : .05;
  drawDriverSky(w, night);
  drawDriverRoad(w, night);
  drawDriverObjects(night);
  drawDriverTarget();
  drawChaseBike(night);
  drawWeatherEffects(w, night);
  drawMiniMap();
}

function drawDriverSky(w, night) {
  const sky = ctx.createLinearGradient(0, 0, 0, innerHeight);
  sky.addColorStop(0, w.sky);
  sky.addColorStop(.42, night > .5 ? "#111c26" : "#8aa8aa");
  sky.addColorStop(.43, "#183124");
  sky.addColorStop(1, "#07100d");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, innerWidth, innerHeight);

  ctx.fillStyle = night > .5 ? "rgba(255,157,54,.35)" : "rgba(255,210,126,.45)";
  ctx.beginPath();
  ctx.arc(innerWidth * .78, innerHeight * .18, 34, 0, TAU);
  ctx.fill();

  ctx.fillStyle = "rgba(5, 13, 18, .26)";
  for (let i = 0; i < 7; i++) {
    const x = (i * 230 - state.player.x * .015) % (innerWidth + 240) - 120;
    const y = innerHeight * (.31 + (i % 3) * .035);
    ctx.beginPath();
    ctx.moveTo(x - 120, innerHeight * .43);
    ctx.lineTo(x, y - 90);
    ctx.lineTo(x + 150, innerHeight * .43);
    ctx.closePath();
    ctx.fill();
  }
}

function drawDriverRoad(w, night) {
  const cx = innerWidth / 2;
  const horizon = innerHeight * .43;
  const bottom = innerHeight;
  const roadTop = innerWidth * .11;
  const roadBottom = innerWidth * .92;

  const road = ctx.createLinearGradient(0, horizon, 0, bottom);
  road.addColorStop(0, w.rain > .2 ? "#3b4f56" : "#343b3d");
  road.addColorStop(1, w.rain > .2 ? "#151f24" : "#202629");
  ctx.fillStyle = road;
  ctx.beginPath();
  ctx.moveTo(cx - roadTop, horizon);
  ctx.lineTo(cx + roadTop, horizon);
  ctx.lineTo(cx + roadBottom, bottom);
  ctx.lineTo(cx - roadBottom, bottom);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = "rgba(255, 230, 155, .55)";
  ctx.lineWidth = 3;
  for (let i = 0; i < 18; i++) {
    const f1 = 160 + i * 120 - (state.player.x * .05 + state.player.y * .03) % 120;
    const f2 = f1 + 55;
    const a = projectDriver(f1, 0);
    const b = projectDriver(f2, 0);
    if (a.y > horizon && a.y < innerHeight + 100) {
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.stroke();
    }
  }

  ctx.strokeStyle = "rgba(255, 255, 255, .28)";
  ctx.lineWidth = 2;
  for (const side of [-180, 180]) {
    ctx.beginPath();
    for (let f = 180; f < 1900; f += 110) {
      const p = projectDriver(f, side);
      if (f === 180) ctx.moveTo(p.x, p.y);
      else ctx.lineTo(p.x, p.y);
    }
    ctx.stroke();
  }

  if (w.rain > .2) {
    for (let i = 0; i < 24; i++) {
      const f = 220 + i * 70;
      const side = Math.sin(i * 1.9 + state.t) * 130;
      const p = projectDriver(f, side);
      ctx.strokeStyle = `rgba(130,190,210,${.08 + w.rain * .16})`;
      ctx.lineWidth = Math.max(1, 18 * p.s / 8);
      ctx.beginPath();
      ctx.ellipse(p.x, p.y, 42 * p.s / 8, 8 * p.s / 8, 0, 0, TAU);
      ctx.stroke();
    }
  }
}

function drawDriverObjects(night) {
  const city = currentCity();
  const landmarks = allLandmarks
    .filter(l => l.city === city)
    .map(l => ({ ...l, d: toDriverSpace(l.x, l.y) }))
    .filter(l => l.d.forward > 50 && l.d.forward < 1750 && Math.abs(l.d.side) < 720)
    .sort((a, b) => b.d.forward - a.d.forward);

  for (const l of landmarks) {
    const p = projectDriver(l.d.forward, l.d.side, 70);
    const size = clamp(48 * p.s, 20, 170);
    const colors = {
      shop: "#ff9d36", fuel: "#50c16b", garage: "#7aaec8", school: "#e9d46a",
      bridge: "#a4aeb5", home: "#d06b4a", park: "#55bd72", atm: "#9bcae6",
      field: "#72b960", forest: "#2f8b55", warehouse: "#696e78", temple: "#f2c36d",
      mosque: "#84d7b0", pond: "#57a6c0", station: "#d9d5c7", hospital: "#ff6a6a",
      police: "#7495e9", bus: "#f09b36", hotel: "#d68cd8", road: "#909b83"
    };
    drawModernBuilding(p.x, p.y, size, colors[l.type] || "#ddd", l.type, night);
    if (size > 26) {
      ctx.fillStyle = "#fff7e8";
      ctx.font = `${clamp(size * .18, 10, 16)}px Rajdhani`;
      ctx.textAlign = "center";
      ctx.fillText(l.name, p.x, p.y - size - 8);
    }
  }

  const vehicles = state.traffic
    .filter(v => v.city === city)
    .map(v => ({ ...v, d: toDriverSpace(v.x, v.y) }))
    .filter(v => v.d.forward > 60 && v.d.forward < 1300 && Math.abs(v.d.side) < 360)
    .sort((a, b) => b.d.forward - a.d.forward);

  for (const v of vehicles) {
    const p = projectDriver(v.d.forward, v.d.side, 16);
    const ww = clamp(70 * p.s, 20, 170);
    const hh = ww * .46;
    drawModernVehicle(p.x, p.y, ww, hh, v.color, v.type);
  }

  for (let i = 0; i < 26; i++) {
    const f = 220 + i * 80;
    for (const side of [-250, 250]) {
      const p = projectDriver(f, side + Math.sin(i + state.t) * 20, 80);
      const h = clamp(120 * p.s, 18, 130);
      ctx.strokeStyle = "#1d452f";
      ctx.lineWidth = clamp(10 * p.s, 2, 10);
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      ctx.lineTo(p.x, p.y - h);
      ctx.stroke();
      ctx.fillStyle = "#347a45";
      ctx.beginPath();
      ctx.arc(p.x, p.y - h, h * .32, 0, TAU);
      ctx.fill();
    }
  }
}

function drawDriverTarget() {
  const mission = state.activeMission;
  if (!mission) return;
  const target = state.missionStage === "pickup" ? mission.pickup : mission.drop;
  const d = toDriverSpace(target.x, target.y);
  if (d.forward < 20) return;
  const p = projectDriver(clamp(d.forward, 80, 1600), clamp(d.side, -360, 360), 130);
  ctx.strokeStyle = state.missionStage === "pickup" ? "#ff9d36" : "#49c56d";
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(p.x, p.y, clamp(1200 / d.forward, 20, 54), 0, TAU);
  ctx.stroke();
  ctx.fillStyle = "rgba(6, 14, 18, .78)";
  drawRoundedRect(p.x - 78, p.y - 48, 156, 28, 13);
  ctx.fillStyle = "#fff";
  ctx.font = "700 13px Rajdhani";
  ctx.textAlign = "center";
  ctx.fillText(`${state.missionStage === "pickup" ? "PICKUP" : "DROP"} ${Math.round(d.forward)}m`, p.x, p.y - 30);
}

function drawModernBuilding(x, y, size, color, type, night) {
  const floors = type === "warehouse" ? 1 : type === "station" || type === "hospital" || type === "hotel" ? 4 : 2;
  const width = size * (type === "warehouse" ? 1.7 : 1.05);
  const height = size * (.75 + floors * .24);
  const roof = type === "temple" || type === "mosque";

  ctx.fillStyle = "rgba(0,0,0,.42)";
  ctx.beginPath();
  ctx.ellipse(x, y - size * .03, width * .62, size * .14, 0, 0, TAU);
  ctx.fill();

  const wall = ctx.createLinearGradient(x - width / 2, y - height, x + width / 2, y);
  wall.addColorStop(0, color);
  wall.addColorStop(1, "#141d22");
  ctx.fillStyle = wall;
  drawRoundedRect(x - width / 2, y - height, width, height, Math.max(5, size * .08));

  ctx.fillStyle = "rgba(255,255,255,.12)";
  ctx.fillRect(x - width / 2 + 3, y - height + 4, width * .12, height - 8);

  if (roof) {
    ctx.fillStyle = type === "mosque" ? "#83dcc2" : "#f3ba55";
    ctx.beginPath();
    ctx.moveTo(x - width * .45, y - height);
    ctx.lineTo(x, y - height - size * .45);
    ctx.lineTo(x + width * .45, y - height);
    ctx.closePath();
    ctx.fill();
  } else {
    ctx.fillStyle = "rgba(8,13,17,.88)";
    ctx.fillRect(x - width * .48, y - height - size * .1, width * .96, size * .12);
  }

  const windowColor = night > .35 ? "rgba(255,174,67,.78)" : "rgba(210,238,242,.42)";
  ctx.fillStyle = windowColor;
  const rows = Math.max(1, floors);
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < 3; c++) {
      const wx = x - width * .28 + c * width * .28;
      const wy = y - height * .78 + r * height * .19;
      ctx.fillRect(wx, wy, width * .11, height * .09);
    }
  }

  if (type === "fuel") {
    ctx.fillStyle = "#f4f6ee";
    ctx.fillRect(x + width * .34, y - height * .5, width * .1, height * .5);
    ctx.fillStyle = "#49c56d";
    ctx.fillRect(x + width * .31, y - height * .61, width * .16, height * .13);
  }
}

function drawModernVehicle(x, y, ww, hh, color, type) {
  const bus = type === "bus" || type === "truck";
  const auto = type === "auto";
  const bike = type === "bike";
  const bodyW = bike ? ww * .62 : bus ? ww * 1.25 : ww;
  const bodyH = bike ? hh * .56 : bus ? hh * 1.1 : hh;

  ctx.fillStyle = "rgba(0,0,0,.46)";
  ctx.beginPath();
  ctx.ellipse(x, y - bodyH * .03, bodyW * .58, bodyH * .2, 0, 0, TAU);
  ctx.fill();

  if (bike) {
    ctx.strokeStyle = "#0c1115";
    ctx.lineWidth = Math.max(2, ww * .08);
    ctx.beginPath();
    ctx.arc(x - bodyW * .3, y - bodyH * .15, bodyW * .18, 0, TAU);
    ctx.arc(x + bodyW * .3, y - bodyH * .15, bodyW * .18, 0, TAU);
    ctx.stroke();
    ctx.fillStyle = color;
    drawRoundedRect(x - bodyW * .28, y - bodyH * .6, bodyW * .56, bodyH * .28, 5);
    ctx.fillStyle = "#eaf5f1";
    ctx.beginPath();
    ctx.arc(x, y - bodyH * .78, bodyH * .18, 0, TAU);
    ctx.fill();
    return;
  }

  ctx.fillStyle = color;
  drawRoundedRect(x - bodyW / 2, y - bodyH, bodyW, bodyH, Math.max(5, ww * .08));

  const glass = ctx.createLinearGradient(x, y - bodyH, x, y - bodyH * .45);
  glass.addColorStop(0, "#bde4ef");
  glass.addColorStop(1, "#233340");
  ctx.fillStyle = glass;
  drawRoundedRect(x - bodyW * .34, y - bodyH * .82, bodyW * .68, bodyH * .3, 4);

  if (auto) {
    ctx.fillStyle = "#f0ca3e";
    ctx.fillRect(x - bodyW * .45, y - bodyH * .98, bodyW * .9, bodyH * .18);
  }

  ctx.fillStyle = "rgba(255,232,164,.9)";
  ctx.fillRect(x - bodyW * .4, y - bodyH * .32, bodyW * .15, bodyH * .12);
  ctx.fillRect(x + bodyW * .25, y - bodyH * .32, bodyW * .15, bodyH * .12);
  ctx.fillStyle = "#05070a";
  ctx.beginPath();
  ctx.arc(x - bodyW * .34, y - bodyH * .02, bodyH * .18, 0, TAU);
  ctx.arc(x + bodyW * .34, y - bodyH * .02, bodyH * .18, 0, TAU);
  ctx.fill();
}

function drawChaseBike(night) {
  const baseY = innerHeight * .78;
  if (night > .4 || currentWeather().fog > .25) {
    const beam = ctx.createRadialGradient(innerWidth / 2, baseY - 56, 20, innerWidth / 2, innerHeight * .45, innerWidth * .52);
    beam.addColorStop(0, "rgba(255,220,150,.22)");
    beam.addColorStop(1, "rgba(255,220,150,0)");
    ctx.fillStyle = beam;
    ctx.fillRect(0, innerHeight * .34, innerWidth, innerHeight * .44);
  }

  const sway = Math.sin(state.t * 4) * Math.min(10, Math.abs(state.player.speed) * 1.4);
  const x = innerWidth / 2 + sway;
  ctx.fillStyle = "rgba(4, 8, 11, .82)";
  ctx.beginPath();
  ctx.ellipse(x, innerHeight + 24, innerWidth * .38, innerHeight * .18, 0, Math.PI, TAU);
  ctx.fill();

  ctx.strokeStyle = "#0b1014";
  ctx.lineWidth = 18;
  ctx.beginPath();
  ctx.moveTo(x - 135, baseY + 30);
  ctx.quadraticCurveTo(x - 80, baseY - 32, x - 22, baseY + 16);
  ctx.moveTo(x + 135, baseY + 30);
  ctx.quadraticCurveTo(x + 80, baseY - 32, x + 22, baseY + 16);
  ctx.stroke();

  ctx.fillStyle = "#101922";
  drawRoundedRect(x - 64, baseY - 18, 128, 68, 24);
  ctx.fillStyle = "#ff9d36";
  drawRoundedRect(x - 24, baseY - 52, 48, 70, 15);
  ctx.fillStyle = "#e8f4ef";
  ctx.beginPath();
  ctx.ellipse(x, baseY - 72, 22, 26, 0, 0, TAU);
  ctx.fill();

  ctx.fillStyle = "rgba(6, 12, 16, .96)";
  ctx.beginPath();
  ctx.arc(x, baseY + 58, 46, 0, TAU);
  ctx.fill();
  ctx.strokeStyle = "#ff9d36";
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(x, baseY + 58, 36, Math.PI * .78, Math.PI * 2.18);
  ctx.stroke();
  ctx.fillStyle = "#eaf7ef";
  ctx.font = "700 20px Rajdhani";
  ctx.textAlign = "center";
  ctx.fillText(`${Math.round(Math.abs(state.player.speed) * 12)}`, x, baseY + 62);
  ctx.font = "11px Rajdhani";
  ctx.fillText("KM/H", x, baseY + 78);
}

function update(dt) {
  if (!state.started) return;
  state.t += dt;
  state.dayMinutes = (state.dayMinutes + dt * 7.5) % 1440;
  state.nextWeather -= dt;
  if (state.nextWeather <= 0) {
    const city = currentCity();
    const night = ["Night", "Midnight", "Early Dawn"].includes(phaseOfDay());
    let choices = city === "Basudevpur" && night
      ? ["Dense Fog", "Morning Mist", "Overcast", "Light Rain"]
      : city === "Howrah" && night
        ? ["Heavy Rain", "Thunderstorm", "Overcast", "Strong Wind"]
        : ["Sunny", "Cloudy", "Overcast", "Light Rain", "Strong Wind"];
    setWeather(choices[Math.floor(Math.random() * choices.length)]);
    state.nextWeather = rnd(55, 110);
    if (currentWeather().name === "Thunderstorm") playStormStartSound();
    showToast(`Weather changed: ${currentWeather().name}.`);
  }

  const w = currentWeather();
  if (w.name === "Thunderstorm" && Math.random() < .006) state.lightning = 1;
  if (state.lightning > .96 && state.t - audio.lastThunder > 3) {
    audio.lastThunder = state.t;
    playThunderSound();
  }
  state.lightning = Math.max(0, state.lightning - dt * 2.8);

  updatePlayer(dt, w);
  updateEnvironmentalAudio();
  checkMoneyMilestones();
  state.camera.x = lerp(state.camera.x, state.player.x + Math.cos(state.player.angle) * 100, .08);
  state.camera.y = lerp(state.camera.y, state.player.y + Math.sin(state.player.angle) * 100, .08);
  updateHud();
}

function updatePlayer(dt, weather) {
  const p = state.player;
  const maxSpeed = 6.5 + p.bikeLevel * 1.1;
  const power = .16 + p.bikeLevel * .018;
  const engineFactor = clamp(p.engine / 100, .28, 1);

  if (input.up && p.fuel > 0 && p.energy > 0) p.speed += power * engineFactor;
  if (input.down || input.brake) p.speed -= .24;
  if (!input.up && !input.down && !input.brake) p.speed *= .985;
  p.speed = clamp(p.speed, -2.5, maxSpeed * weather.grip);

  const steer = (input.left ? -1 : 0) + (input.right ? 1 : 0);
  if (Math.abs(p.speed) > .12 && steer) {
    p.angle += steer * (.034 + .014 * weather.wind) * Math.sign(p.speed);
  }

  if (weather.wind > .5 && Math.abs(p.speed) > 3) {
    p.angle += Math.sin(state.t * 2.2) * weather.wind * .002;
  }

  p.x += Math.cos(p.angle) * p.speed * 60 * dt;
  p.y += Math.sin(p.angle) * p.speed * 60 * dt;

  const moving = Math.abs(p.speed);
  p.fuel = clamp(p.fuel - moving * dt * (.035 + p.bikeLevel * .004), 0, 100);
  p.energy = clamp(p.energy - moving * dt * .006 - dt * .006, 0, 100);
  p.hunger = clamp(p.hunger - dt * .011, 0, 100);
  p.dirt = clamp(p.dirt + dt * (weather.rain > .2 ? .11 : .012) + moving * dt * .015, 0, 100);
  if (weather.rain > .7 && moving > 5.5) p.engine = clamp(p.engine - dt * .09, 0, 100);
  if (p.fuel <= 0) p.speed *= .96;
  if (p.hunger <= 5) p.energy = clamp(p.energy - dt * .04, 0, 100);
}

function updateHud() {
  const p = state.player;
  ui.hudName.textContent = p.name;
  ui.money.textContent = `₹${Math.round(p.money)}`;
  ui.time.textContent = `${timeLabel()} ${phaseOfDay()}`;
  ui.weather.textContent = currentWeather().name;
  ui.fuel.value = p.fuel;
  ui.health.value = p.health;
  ui.energy.value = p.energy;
  ui.rep.value = p.reputation;

  if (state.activeMission) {
    const m = state.activeMission;
    const target = state.missionStage === "pickup" ? m.pickup : m.drop;
    ui.missionTitle.textContent = `${m.id}. ${m.title}`;
    ui.missionText.textContent = `${state.missionStage === "pickup" ? "Pickup" : "Deliver"} at ${target.name}. Distance ${Math.round(Math.hypot(p.x - target.x, p.y - target.y))}m. Press Interact when close.`;
  } else {
    const next = missions[state.completed];
    ui.missionTitle.textContent = next ? `Next: ${next.title}` : "Story complete";
    ui.missionText.textContent = next
      ? "Open the phone to accept deliveries, read Shadow Notes, travel, repair, or upgrade."
      : "Free roam unlocked. Repeat jobs, explore, and prepare for future multiplayer updates.";
  }
}

function loop(now) {
  const dt = Math.min(.033, (now - (loop.last || now)) / 1000);
  loop.last = now;
  update(dt);
  drawWorld();
  requestAnimationFrame(loop);
}

function togglePhone(force) {
  const open = typeof force === "boolean" ? force : !ui.phone.classList.contains("open");
  ui.phone.classList.toggle("open", open);
  if (open) renderPhone();
}

function keyMap(code, value) {
  if (code === "ArrowUp" || code === "KeyW") input.up = value;
  if (code === "ArrowDown" || code === "KeyS") input.down = value;
  if (code === "ArrowLeft" || code === "KeyA") input.left = value;
  if (code === "ArrowRight" || code === "KeyD") input.right = value;
  if (code === "Space") input.brake = value;
  if (code === "KeyE" && value) interact();
  if (code === "KeyH" && value) playHorn();
  if (code === "KeyP" && value) togglePhone();
}

function bindControls() {
  addEventListener("resize", resize);
  addEventListener("keydown", e => keyMap(e.code, true));
  addEventListener("keyup", e => keyMap(e.code, false));
  document.querySelectorAll("#mobileControls button").forEach(btn => {
    const k = btn.dataset.key;
    const down = e => {
      e.preventDefault();
      if (k === "interact") interact();
      else if (k === "phone") togglePhone();
      else if (k === "horn") playHorn();
      else input[k] = true;
    };
    const up = e => {
      e.preventDefault();
      if (k !== "interact" && k !== "phone") input[k] = false;
    };
    btn.addEventListener("pointerdown", down);
    btn.addEventListener("pointerup", up);
    btn.addEventListener("pointercancel", up);
    btn.addEventListener("pointerleave", up);
  });

  document.querySelectorAll(".tabs button").forEach(btn => {
    btn.addEventListener("click", () => {
      state.tab = btn.dataset.tab;
      renderPhone();
    });
  });
  ui.closePhone.addEventListener("click", () => togglePhone(false));
  ui.hudToggle.addEventListener("click", () => {
    ui.hud.classList.toggle("minimal");
    ui.hudToggle.textContent = ui.hud.classList.contains("minimal") ? "HUD+" : "HUD";
  });
  ui.closeCongrats.addEventListener("click", () => {
    ui.congratsPopup.classList.remove("show");
  });
  ui.startBtn.addEventListener("click", () => {
    initAudio();
    state.player.name = (ui.riderName.value || "AFROJ").trim().slice(0, 16);
    state.started = true;
    ui.hud.classList.add("minimal");
    ui.hudToggle.textContent = "HUD+";
    ui.start.classList.remove("active");
    showToast(`Welcome, ${state.player.name}. Your shift begins in Chengail.`);
    renderPhone();
  });
}

resize();
spawnWorldActors();
bindControls();
requestAnimationFrame(loop);
